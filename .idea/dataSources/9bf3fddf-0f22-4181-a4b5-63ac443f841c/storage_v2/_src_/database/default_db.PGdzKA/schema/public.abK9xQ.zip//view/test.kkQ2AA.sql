create view test(admin_id, username) as
SELECT admins.admin_id,
       admins.username
FROM admins;

alter table test
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on test to admin;

