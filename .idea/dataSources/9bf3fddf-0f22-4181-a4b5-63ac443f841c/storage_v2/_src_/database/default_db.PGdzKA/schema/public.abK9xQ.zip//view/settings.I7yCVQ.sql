create view settings(message_info, message) as
SELECT admin_settings.message_info,
       admin_settings.message
FROM admin_settings;

alter table settings
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on settings to admin;

