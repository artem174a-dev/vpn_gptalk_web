create view customers_info
            (customer_id, organization_id, customer_type, username, phone_number, organization_name, count_applications,
             address) as
SELECT customers.customer_id,
       customers.organization_id,
       customers.customer_type,
       customers.username,
       customers.phone_number,
       customers.organization_name,
       customers.count_applications,
       customers.address
FROM customers;

alter table customers_info
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on customers_info to admin;

