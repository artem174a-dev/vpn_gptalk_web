create view couriers_info
            (courier_id, username, phone_number, privileges_type, count_applications, count_good_appllications,
             receiving_order) as
SELECT couriers.courier_id,
       couriers.username,
       couriers.phone_number,
       couriers.privileges_type,
       couriers.count_applications,
       couriers.count_good_appllications,
       couriers.receiving_order
FROM couriers;

alter table couriers_info
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on couriers_info to admin;

