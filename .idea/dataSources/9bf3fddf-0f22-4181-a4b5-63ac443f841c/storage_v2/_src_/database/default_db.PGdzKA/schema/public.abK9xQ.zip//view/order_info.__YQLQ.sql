create view order_info
            (organization_name, order_id, courier_id, customer_id, status, courier_name, customer_name, point_a,
             point_b, price, comment, create_order_time, start_time, end_time, rownum)
as
WITH rankedorders AS (SELECT customers.organization_name,
                             orders.order_id,
                             orders.courier_id,
                             orders.customer_id,
                             order_details.status,
                             order_details.courier_name,
                             order_details.customer_name,
                             order_details.point_a,
                             order_details.point_b,
                             order_details.price,
                             order_details.comment,
                             orders.create_order_time,
                             order_details.start_time,
                             order_details.end_time,
                             row_number()
                             OVER (PARTITION BY orders.order_id ORDER BY orders.create_order_time DESC) AS rownum
                      FROM orders
                               JOIN customers ON orders.customer_id = customers.customer_id
                               LEFT JOIN order_details ON orders.order_id = order_details.order_id)
SELECT rankedorders.organization_name,
       rankedorders.order_id,
       rankedorders.courier_id,
       rankedorders.customer_id,
       rankedorders.status,
       rankedorders.courier_name,
       rankedorders.customer_name,
       rankedorders.point_a,
       rankedorders.point_b,
       rankedorders.price,
       rankedorders.comment,
       rankedorders.create_order_time,
       rankedorders.start_time,
       rankedorders.end_time,
       rankedorders.rownum
FROM rankedorders
WHERE rankedorders.rownum = 1
ORDER BY rankedorders.create_order_time DESC;

alter table order_info
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on order_info to admin;

